package assign9;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.testng.Assert.assertTrue;

import Infrastructure.Loadproperties;
import io.github.bonigarcia.wdm.WebDriverManager;

public class crud {
  
	
	public static WebDriver driver = null;
	@SuppressWarnings("unused")
	private static Object TakesScreenshot;
	
	@SuppressWarnings("unused")
	public static void Configuration() {
		

		WebDriverManager.chromedriver().clearDriverCache().setup();
		 driver = new ChromeDriver();
		
	}
	public static void result() {
		String CurrentURL = driver.getCurrentUrl();
		if(CurrentURL.contains(driver.getCurrentUrl())) {
					assertTrue(true, "Printer is not added Sucessfully");
	}
}
	
	
	public static void Login() throws IOException {
		
		String Sheetpath = "/home/madhuri.parekh/eclipse-workspace/Assignment8/src/main/java/printer/testassign.xlsx"; 
		String Sheetname = "Login";
		Infrastructure.Loadproperties.getproperties("/home/madhuri.parekh/eclipse-workspace/Assignment8/src/test/resources/login.properties");
		

		driver.get("https://ops-qa.4onprintshop.com/admin");
		driver.manage().window().maximize();
		
		
		/*driver.findElement(By.id("username")).sendKeys("admin");
		driver.findElement(By.id("password")).sendKeys("Admin095");
		driver.findElement(By.name("login")).click();*/
		
		
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("username"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"username"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("password"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"password"));
		
		//screenshot 
		TakesScreenshot screenshot = (TakesScreenshot)driver;
		File source = screenshot.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source, new File("/home/madhuri.parekh/eclipse-workspace/Screenshots/login.png"));
	
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("loginbutton"))).click();
		result();
		
	}
	

	public static void Register() throws IOException {
		
		
		String Sheetpath = "/home/madhuri.parekh/eclipse-workspace/Assignment8/src/main/java/printer/testassign.xlsx" ; 
		String Sheetname = "Printer";
		
		Infrastructure.Loadproperties.getproperties("/home/madhuri.parekh/eclipse-workspace/Assignment8/src/test/resources/printer.properties");
		

		driver.get("https://ops-qa.4onprintshop.com/admin/printer_action.php");
		driver.manage().window().maximize();
		
		
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("printername"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"printername"));		
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("email"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"email"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("username"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"username"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("password"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"password"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("notes"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"notes"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("address1"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"address1"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("city"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"city"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("statebutton"))).click();
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("state"))).click();
		
		//screenshot
		TakesScreenshot screenshot = (TakesScreenshot)driver;
		File source = screenshot.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source, new File("/home/madhuri.parekh/eclipse-workspace/Screenshots/add.png"));
	
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("saveandback"))).click();
		
		result();
}
	
	public static void Edit() throws IOException {

		String Sheetpath = "/home/madhuri.parekh/eclipse-workspace/Assignment9/src/main/java/assign9/testassign.xlsx" ; 
		String Sheetname = "Edit";
		
		Infrastructure.Loadproperties.getproperties("/home/madhuri.parekh/eclipse-workspace/Assignment9/src/test/resources/printer.properties");
		

		//driver.get("https://ops-qa.4onprintshop.com/admin/printer_listing.php");
		//driver.manage().window().maximize();
		
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("search"))).sendKeys("one");
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("actionbutton"))).click();
		
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("editicon"))).click();
		
		
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("printername"))).clear();
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("printername"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"printername"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("email"))).clear();
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("email"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"email"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("username"))).clear();
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("username"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"username"));
		//driver.findElement(By.xpath(Loadproperties.obj.getProperty("password"))).clear();
		//driver.findElement(By.xpath(Loadproperties.obj.getProperty("password"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"password"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("notes"))).clear();
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("notes"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"notes"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("address1"))).clear();
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("address1"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"address1"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("city"))).clear();
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("city"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"city"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("statebutton"))).click();
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("stateupdate"))).click();
		
		//screenshot
		TakesScreenshot screenshot = (TakesScreenshot)driver;
		File source = screenshot.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source, new File("/home/madhuri.parekh/eclipse-workspace/Screenshots/edit.png"));
	
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("saveandback"))).click();
		result();
	}
	public static void Delete() throws InterruptedException, IOException {
		
		driver.get("https://ops-qa.4onprintshop.com/admin/printer_listing.php");
		
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("search"))).clear();
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("search"))).sendKeys("two");
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("actionbutton"))).click();
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("deleteicon"))).click();
		
		Thread.sleep(2000);
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("okbutton"))).click();
		
		//screenshot
		TakesScreenshot screenshot = (TakesScreenshot)driver;
		File source = screenshot.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source, new File("/home/madhuri.parekh/eclipse-workspace/Screenshots/delete.png"));
	
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("search"))).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("search"))).clear();
		driver.get("https://ops-qa.4onprintshop.com/admin/printer_listing.php");
		
		result();
	}
	
	
	public static void main(String[] args) throws InterruptedException, IOException
	
	{
		Configuration();
		Login();
		Register();
		Edit();
		Delete();
		
		driver.close();
		
	}
	

}
