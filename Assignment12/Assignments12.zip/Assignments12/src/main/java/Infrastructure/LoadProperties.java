package Infrastructure;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class LoadProperties {

	public static Properties obj  = new Properties();
	
	// Get Properties Function to load Properties file.
	public static String getproperties(String path) throws IOException {
		
		/**
		 *  Properties : It is Inbuild function to load .Properties file 
		 *  Path : It's File path
		 *  InputStream is load Properties file
		 *  
		 */
		
		File objFile = new File(path);
		
		FileInputStream IStream = new FileInputStream(objFile);
		
	/*	if(IStream!=null) {
			IStream = null;
		}*/
		
		obj.load(IStream);
		
		return "";
		
	}

}