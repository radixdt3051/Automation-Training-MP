package Infrastructure;

	import java.io.File;
	import java.io.IOException;
	import java.sql.Driver;
	import java.util.Random;

	import static org.testng.Assert.assertTrue;

	import org.testng.annotations.Test;
	import org.testng.annotations.AfterMethod;
	import org.testng.annotations.BeforeMethod;
	import org.testng.annotations.Parameters;
	import org.testng.annotations.AfterSuite;

	import org.apache.commons.io.FileUtils;

	import org.openqa.selenium.By;
	import org.openqa.selenium.OutputType;
	import org.openqa.selenium.TakesScreenshot;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;

	import Infrastructure.LoadProperties;
	import Infrastructure.Readfile;
	import io.github.bonigarcia.wdm.WebDriverManager;



	public class Assign12 {
		
		static WebDriver driver=null;
		
		static {
			WebDriverManager.chromedriver().clearDriverCache().setup();
			driver = new ChromeDriver();	
		}
	
		public static String Sheetobjpath , Sheetobjname , PropertiesobjFile ;
		
		@BeforeMethod(alwaysRun = true)
		@Parameters({"Sheetobjpath","Sheetobjname","PropertiesFile"})
		public void Configuration(String Sheetpath , String Sheetname , String PropertiesFile) {
			
			this.Sheetobjpath  = Sheetpath ; 
			this.Sheetobjname  = Sheetname ; 
			this.PropertiesobjFile  = PropertiesFile; 
			//System.out.println(Sheetobjpath);

		}
		
			
		@Test(priority = 0)
		public static void Login() throws IOException {

			driver.get("https://ops-qa.4onprintshop.com/admin/index.php");
			driver.manage().window().maximize();
			
			int mp = Infrastructure.Readfile.RowCount(Sheetobjpath,Sheetobjname);		
			
			
			Infrastructure.LoadProperties.getproperties(PropertiesobjFile);
			
		
			for(int i =1 ; i<=mp; i++) {	
			
				driver.findElement(By.xpath(LoadProperties.obj.getProperty("username"))).sendKeys(Readfile.getExeldetails(i,Sheetobjpath,Sheetobjname,"username"));
				driver.findElement(By.xpath(LoadProperties.obj.getProperty("password"))).sendKeys(Readfile.getExeldetails(i,Sheetobjpath,Sheetobjname,"password"));
				driver.findElement(By.xpath(LoadProperties.obj.getProperty("loginbutton"))).click();
		
			}
		}
		
		
	/**	@Test(priority = 1)
		public static void Add() throws IOException, InterruptedException {
		
			Infrastructure.LoadProperties.getproperties(PropertiesobjFile);
			
			driver.get("https://ops-qa.4onprintshop.com/admin/printer_action.php");
			
			
			int mp= Infrastructure.Readfile.RowCount(Sheetobjpath,Sheetobjname);**/
			
		//}
		
		@Test(priority = 2)
		public static void Update() throws IOException, InterruptedException {
			
			Infrastructure.LoadProperties.getproperties(PropertiesobjFile);

			driver.findElement(By.xpath(LoadProperties.obj.getProperty("search"))).sendKeys("one");
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("actionbutton"))).click();
			
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("editicon"))).click();
			
			
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("printername"))).clear();
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("printername"))).sendKeys(Readfile.getExeldetails(0, Sheetobjpath,Sheetobjname,"printername"));
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("email"))).clear();
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("email"))).sendKeys(Readfile.getExeldetails(0,Sheetobjpath,Sheetobjname,"email"));
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("username"))).clear();
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("username"))).sendKeys(Readfile.getExeldetails(0,Sheetobjpath,Sheetobjname,"username"));
			//driver.findElement(By.xpath(LoadProperties.obj.getProperty("password"))).clear();
			//driver.findElement(By.xpath(LoadProperties.obj.getProperty("password"))).sendKeys(Readfile.getExeldetails(0,Sheetobjpath,Sheetobjname,"password"));
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("notes"))).clear();
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("notes"))).sendKeys(Readfile.getExeldetails(0,Sheetobjpath,Sheetobjname,"notes"));
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("address1"))).clear();
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("address1"))).sendKeys(Readfile.getExeldetails(0,Sheetobjpath,Sheetobjname,"address1"));
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("city"))).clear();
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("city"))).sendKeys(Readfile.getExeldetails(0,Sheetobjpath,Sheetobjname,"city"));
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("statebutton"))).click();
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("stateupdate"))).click();
			
			//screenshot
			TakesScreenshot screenshot = (TakesScreenshot)driver;
			File source = screenshot.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(source, new File("/home/madhuri.parekh/eclipse-workspace/Screenshots/edit.png"));
		
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("saveandback"))).click();
			result();
			}
		
		@Test(priority = 3)
		public static void Delete() throws IOException, InterruptedException {
			
		
			Infrastructure.LoadProperties.getproperties(PropertiesobjFile);

			driver.findElement(By.xpath(LoadProperties.obj.getProperty("search"))).clear();
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("search"))).sendKeys("two");
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("actionbutton"))).click();
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("deleteicon"))).click();
			
			Thread.sleep(2000);
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("okbutton"))).click();
			
			//screenshot
			TakesScreenshot screenshot = (TakesScreenshot)driver;
			File source = screenshot.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(source, new File("/home/madhuri.parekh/eclipse-workspace/Screenshots/delete.png"));
		
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("search"))).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath(LoadProperties.obj.getProperty("search"))).clear();
			driver.get("https://ops-qa.4onprintshop.com/admin/printer_listing.php");
			
			result();
			}
		
		
		public static void Register(int r,String Sheetobjpath,String Sheetobjname, String Method) throws InterruptedException, IOException {
			
			for(int i =1 ; i<=r; i++) { 
				
				
				
				
				driver.findElement(By.xpath(LoadProperties.obj.getProperty("printername"))).sendKeys(Readfile.getExeldetails(i,Sheetobjpath,Sheetobjname,"printername"));		
				driver.findElement(By.xpath(LoadProperties.obj.getProperty("email"))).sendKeys(Readfile.getExeldetails(i,Sheetobjpath,Sheetobjname,"email"));
				driver.findElement(By.xpath(LoadProperties.obj.getProperty("username"))).sendKeys(Readfile.getExeldetails(i,Sheetobjpath,Sheetobjname,"username"));
				driver.findElement(By.xpath(LoadProperties.obj.getProperty("password"))).sendKeys(Readfile.getExeldetails(i,Sheetobjpath,Sheetobjname,"password"));
				driver.findElement(By.xpath(LoadProperties.obj.getProperty("notes"))).sendKeys(Readfile.getExeldetails(i,Sheetobjpath,Sheetobjname,"notes"));
				driver.findElement(By.xpath(LoadProperties.obj.getProperty("address1"))).sendKeys(Readfile.getExeldetails(i,Sheetobjpath,Sheetobjname,"address1"));
				driver.findElement(By.xpath(LoadProperties.obj.getProperty("city"))).sendKeys(Readfile.getExeldetails(i,Sheetobjpath,Sheetobjname,"city"));
				driver.findElement(By.xpath(LoadProperties.obj.getProperty("statebutton"))).click();
				driver.findElement(By.xpath(LoadProperties.obj.getProperty("state"))).click();
			
				//screenshot
				TakesScreenshot screenshot = (TakesScreenshot)driver;
				File source = screenshot.getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(source, new File("/home/madhuri.parekh/eclipse-workspace/Screenshots/add.png"));
			
				driver.findElement(By.xpath(LoadProperties.obj.getProperty("saveandback"))).click();

				result();
				}
		}
			

		@AfterMethod
		public static void result() {
			String CurrentURL = driver.getCurrentUrl();
			if(CurrentURL.contains(driver.getCurrentUrl())) {
						assertTrue(true, "Printer is not added Sucessfully");
			}
		}
		
		@AfterSuite
		public static void after() {
			System.out.println("Testing is running");
	
			driver.close();
			}
	}
	

