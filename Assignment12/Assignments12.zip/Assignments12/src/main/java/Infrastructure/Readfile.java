package Infrastructure;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.poifs.filesystem.NotOLE2FileException;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;

public class Readfile {

	public static FileInputStream FIS;
	
	public static HSSFWorkbook wb;
	
	public static HSSFSheet sheet2;
	
	public static int rowCount;
	
	public static String cellkey=null;
	
	public static String cellvalue=null;
	
	public static Row r1;
	
	
	
	public static int RowCount(String Sheetpath,String sheetname) throws IOException {
		
		
		File objfile = new File(Sheetpath);
		
		FIS = new FileInputStream(objfile);
	
		 wb = new HSSFWorkbook(FIS);
		
		sheet2 = wb.getSheet(sheetname);
	
		 rowCount = sheet2.getLastRowNum()-sheet2.getFirstRowNum();
		 
		 return rowCount;
	}
	
	
	
	public static String getExeldetails(int row ,String Sheetpath,String sheetname, String columnName) throws IOException {

		
		for(int i =0; i<rowCount; i++)
		{
		 r1 = sheet2.getRow(i);
			
			for(int j =0; j< r1.getLastCellNum();j++)
			{
				
				String cellValue = r1.getCell(j).toString();
				
				if(cellValue.equals(columnName))
				{
					Row row2 = sheet2.getRow(row);
					cellvalue = row2.getCell(j).toString();
					break;
				}
			}		
			
		}
		
        wb.close();
        FIS.close();
       
		
		return cellvalue;
	}
	
	}
	
