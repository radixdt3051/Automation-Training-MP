package Assignment07;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.v124.media.model.Timestamp;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Program7_1 {

	public static void main(String[] args) throws InterruptedException {

			WebDriverManager.chromedriver().clearDriverCache().setup();
			ChromeDriver driver = new ChromeDriver();
			
			driver.get("https://ops-qa.4onprintshop.com/admin");
			driver.manage().window().maximize();
			
			System.out.println(driver.getTitle());
			System.out.println(driver.getCurrentUrl());
			
			driver.findElement(By.id("username")).sendKeys("admin");
			driver.findElement(By.id("password")).sendKeys("Admin095");
			driver.findElement(By.name("login")).click();
			
			
			driver.get("https://ops-qa.4onprintshop.com/admin/printer_action.php");
			driver.findElement(By.xpath("//*[@id='printername']")).sendKeys("Testing printer");
			driver.findElement(By.xpath("//*[@id='username']")).sendKeys("MAITRI");
			driver.findElement(By.xpath("//input[@id='order_notify']//preceding::textarea[@id='notes']")).sendKeys("Testing is running");
			driver.findElement(By.xpath("//input[@id='printername']//following::input[@id='email']")).sendKeys("madhuri.parekh@radixweb.com");
			driver.findElement(By.xpath("//span[@class='erequired input-group-addon block_white align-top text-danger pl-1']//preceding-sibling::input[@id='password']")).sendKeys("Admin@123");
			driver.findElement(By.xpath("//span[contains(@class,'erequired input-group-addon block_white align-top text-danger pl-1')]//preceding-sibling::input[contains(@id,'street_address')]")).sendKeys("Street address 1");
			driver.findElement(By.xpath("//div[@class='col-md-6']//descendant::input[@id='city']")).sendKeys("Ahmedabad");
			driver.findElement(By.xpath("//button[@data-id='state']")).click();			
			driver.findElement(By.xpath("//select[@id='state']//following-sibling::div[@class='dropdown-menu show']//ul//li//a/span[text()='Arizona']")).click();
			
			driver.findElement(By.xpath("//button[@id='btn-action-saveback']")).click();
			
			Thread.sleep(5000);
			
			driver.close();
		
			}

	}
		

		
		
		

	

