package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class program13 {
	
	
final WebDriver driver;
	
	public program13(WebDriver driver) {
		this.driver=driver;
		
	}
	
	@FindBy(id="printername")
	WebElement printername;
	
	@FindBy(id="email")
	WebElement email;
	
	@FindBy(id="username")
	WebElement username;
	
	@FindBy(id="password")
	WebElement password;
	
	@FindBy(id="street_address")
	WebElement address1;
	
	@FindBy(id="city")
	WebElement city;
	
	@FindBy(xpath="//button[@data-id='state']")
	WebElement state;
	
	@FindBy(xpath="//select[@id='state']//following-sibling::div[contains(@class,'dropdown-menu')]//ul//li//a/span[text()='Alaska']")
	WebElement statetext;
	
	@FindBy(id="btn-action-saveback")
	WebElement saveandback;
	
	
	public void add_action(String pname, String mail, String usname, String pwdd, String add1, String cty, String st) {
		printername.sendKeys(pname);
		email.sendKeys(mail);
		username.sendKeys(usname);
		password.sendKeys(pwdd);
		address1.sendKeys(add1);
		city.sendKeys(cty);
		state.click();
		statetext.sendKeys(st);
		saveandback.click();
	}
		
}