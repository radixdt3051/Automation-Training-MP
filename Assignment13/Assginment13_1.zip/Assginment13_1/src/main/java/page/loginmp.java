package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;



public class loginmp {
	
	final WebDriver testdriver;
	
	public loginmp(WebDriver driver) {
		this.testdriver=driver;
		
	}
	
	@FindBy(id="username")
	WebElement username;
	
	@FindBy(id="password")
	WebElement pswd;
	
	@FindBy(name="login")
	WebElement loginbtn;
	
	public void login_action(String uname, String pwd) {
		username.sendKeys(uname);
		pswd.sendKeys(pwd);
		loginbtn.click();
	}
		
}