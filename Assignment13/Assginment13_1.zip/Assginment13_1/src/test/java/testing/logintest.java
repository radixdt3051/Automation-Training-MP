package testing;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import io.github.bonigarcia.wdm.WebDriverManager;
import page.loginmp;
import page.program13;


public class logintest {
	
	static WebDriver driver;
	
	
    public static void main(String[] args) throws Exception {
	
        WebDriverManager.chromedriver().setup();

    	 driver = new ChromeDriver();
		String ops = "https://ops-qa.4onprintshop.com/admin";
		driver.get(ops);
		driver.manage().window().maximize();
		
		
    	loginmp loginn = PageFactory.initElements(driver,loginmp.class);
    	loginn.login_action("admin","Admin095");
    	
    	//Add
    	
    	String add = "https://ops-qa.4onprintshop.com/admin/printer_action.php";
		driver.get(add);
		
    	program13 printer = PageFactory.initElements(driver, program13.class);
    	printer.add_action("MPprinter", "mp@radixweb.com", "Madhuri", "Admin@123", "Ekyarth,radixweb", "Ahmedabad", "Alaska");
    	
    	driver.quit();
	}
}
