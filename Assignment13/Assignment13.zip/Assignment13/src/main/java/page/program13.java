package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class program13 {

    WebDriver driver;
    
 
    By pname = By.id("printername");
    By emaill = By.id("email");
    By uname = By.id("username");
    By pwd = By.id("password");
    By address = By.id("street_address");
    By ct = By.id("city");
    By state = By.xpath("//button[@data-id='state']");
    By statebutton = By.xpath("//select[@id='state']//following-sibling::div[contains(@class,'dropdown-menu')]//ul//li//a/span[text()='Alaska']");
    By saveandback = By.id("btn-action-saveback");
    
    
    
    public program13(WebDriver driver) {
        this.driver = driver;
        
    }

    public void Addprinter(String printername, String email, String username, String password, String street_address, String city) {
     
    	
   
    driver.findElement(pname).sendKeys(printername);
    driver.findElement(emaill).sendKeys(email);	
    driver.findElement(uname).sendKeys(username);	
    driver.findElement(pwd).sendKeys(password);
    driver.findElement(address).sendKeys(street_address);
    driver.findElement(ct).sendKeys(city);
    driver.findElement(state).click();
    driver.findElement(statebutton).click();
    driver.findElement(saveandback).click();
 
    }
}