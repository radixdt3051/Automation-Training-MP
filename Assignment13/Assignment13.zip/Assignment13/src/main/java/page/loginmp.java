package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginmp {
    WebDriver driver;

    By uname = By.id("username");
    By pwd = By.id("password");
    By loginbtn = By.name("login");

    
    public loginmp(WebDriver driver) {
        this.driver = driver;
    }

    public void login_action(String username, String password) {
    	
     driver.findElement(uname).sendKeys(username);
     driver.findElement(pwd).sendKeys(password);
     driver.findElement(loginbtn).click();
     
 
    }

}