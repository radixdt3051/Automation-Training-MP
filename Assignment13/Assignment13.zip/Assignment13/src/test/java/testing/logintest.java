package testing;

import page.program13;
import page.loginmp;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class logintest {
	
	ChromeDriver driver = new ChromeDriver();
	
	@BeforeClass
	public void setup() {		
	
		String ops = "https://ops-qa.4onprintshop.com/admin/";
		driver.get(ops);
		driver.manage().window().maximize();
		
		
	}

	@Test(priority = 0)
    public void login_action() {
    	
    	loginmp loginn = new loginmp(driver);
        loginn.login_action("admin", "Admin095");
    }
    
	@Test(priority = 1)
    public void Addprinter() {
    	
		String add = "https://ops-qa.4onprintshop.com/admin/printer_action.php";
		driver.get(add);
    	
		program13 printer = new program13(driver);
		printer.Addprinter("MPprinter", "mp@radixweb.com", "Madhuri", "Admin@123", "Ekyarth,radixweb", "Ahmedabad");
      
        }

        
    }