package Infrastructure;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Loadproperties {

		public static Properties obj = new Properties();
		
		@SuppressWarnings("resource")
		public static String getproperties(String path) throws IOException {
			
			File file = new File(path);
			
			FileInputStream IStream = new FileInputStream(file);
			
		/*	if(IStream!=null) {
				
				IStream = null;
				
			}*/
			
			obj.load(IStream);
			
			return "";
			
		}
		
	}

