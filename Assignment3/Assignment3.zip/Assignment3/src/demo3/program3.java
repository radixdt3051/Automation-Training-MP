package demo3;

import java.util.Scanner;

public class program3 {
	
	public static void main(String[] args) {

		Scanner sc =  new Scanner(System.in);
		System.out.println("Enter Full Name:");
		String test = sc.nextLine();
		
		String[] names = test.split(" ");
		
		String firstname = names[0];
		String middlename = names[1];
		String lastname = names[2];
		
		char firstinitial = firstname.charAt(0);
		char middleinitial = middlename.charAt(0);
		
		System.out.println(firstinitial +"."+ middleinitial +"."+ lastname);
		
	}
	
}