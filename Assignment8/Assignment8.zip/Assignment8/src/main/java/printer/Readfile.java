package printer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;


import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Readfile {

	public static String cellkey=null;
	
	public static String cellvalue=null;

	public static String getExeldetails(String Sheetpath,String sheetname, String columnName) throws IOException {

		
		File objfile = new File(Sheetpath);
		
		FileInputStream FIS = new FileInputStream(objfile);
		
	
		XSSFWorkbook wb = new XSSFWorkbook(FIS);
		
		XSSFSheet sheet2 = wb.getSheet(sheetname);
	
		int rowCount = sheet2.getLastRowNum()-sheet2.getFirstRowNum();
		
        for(int i=0; i<= rowCount; i++){
            
            int cellcount = sheet2.getRow(i).getLastCellNum();
            
            System.out.println("\nRow "+ i +" data is :");
            
            System.out.println(cellcount);
            
            for(int j=0;j<cellcount;j++){
               // System.out.print(sheet2.getRow(i).getCell(j).getStringCellValue() + ", ");
            	
            	cellkey= sheet2.getRow(i).getCell(j).getStringCellValue();
            	
            	if(cellkey.equalsIgnoreCase(columnName)) {
            		
            		cellvalue= sheet2.getRow(1).getCell(j).getStringCellValue();
            		System.out.println(cellvalue);
            		break;
            	}
            }
        }
        wb.close();
        FIS.close();
       
		
		return cellvalue;
	}
	
	}
	