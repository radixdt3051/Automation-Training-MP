package printer;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Infrastructure.Loadproperties;

import io.github.bonigarcia.wdm.WebDriverManager;

public class printertest {
  
	
	public static WebDriver driver = null;
	
	@SuppressWarnings("unused")
	public static void Configuration() {
		

		WebDriverManager.chromedriver().clearDriverCache().setup();
		driver = new ChromeDriver();
		
	}
	
	public static void Login() throws IOException {
		
		String Sheetpath = "/home/madhuri.parekh/eclipse-workspace/Assignment8/src/main/java/printer/testassign.xlsx"; 
		String Sheetname = "Login";
		Infrastructure.Loadproperties.getproperties("/home/madhuri.parekh/eclipse-workspace/Assignment8/src/test/resources/login.properties");
		

		driver.get("https://ops-qa.4onprintshop.com/admin");
		driver.manage().window().maximize();
		
		
		/*driver.findElement(By.id("username")).sendKeys("admin");
		driver.findElement(By.id("password")).sendKeys("Admin095");
		driver.findElement(By.name("login")).click();*/
		
		
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("username"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"username"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("password"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"password"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("loginbutton"))).click();
		
	}
	

	public static void Register() throws IOException {
		
		String Sheetpath = "/home/madhuri.parekh/eclipse-workspace/Assignment8/src/main/java/printer/testassign.xlsx" ; 
		String Sheetname = "Printer";
		
		Infrastructure.Loadproperties.getproperties("/home/madhuri.parekh/eclipse-workspace/Assignment8/src/test/resources/printer.properties");
		

		driver.get("https://ops-qa.4onprintshop.com/admin/printer_action.php");
		driver.manage().window().maximize();
		
		
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("printername"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"printername"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("email"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"email"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("username"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"username"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("password"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"password"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("notes"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"notes"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("address1"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"address1"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("city"))).sendKeys(Readfile.getExeldetails(Sheetpath,Sheetname,"city"));
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("statebutton"))).click();
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("state"))).click();
		driver.findElement(By.xpath(Loadproperties.obj.getProperty("saveandback"))).click();
	
}
	public static void main(String[] args) throws InterruptedException, IOException
	
	{
		Configuration();
		Login();
		Register();
		
		driver.close();
		
	}
	

}
