package Madhuri_Package;

import java.util.Scanner;

/*public class Program3 {
	int i;
  public static void main(String[] args)
  {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter your first five name:");
	String a = sc.nextLine();
	System.out.println(a);
	
	System.out.println("Enter your last five name:");
	String b = sc.nextLine();
	System.out.println(b);
	
	
	for(a=1;a<5;a++) {
	
String name = a.concat(" "+ b);

System.out.println(name);
	
}
	
String name = a.concat(" "+ b);

System.out.println(name);
	

  }
}*/


	
	
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
//import java.util.Scanner;

public class Program3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       
        String[] firstNames = new String[5];
        String[] lastNames = new String[5];
     
        
        System.out.println("Enter 5 first names:");
        for (int i = 0; i < 5; i++) {
            firstNames[i] = scanner.nextLine();
            
        }
     
        
        
        System.out.println("Enter 5 last names:");
        for (int i = 0; i < 5; i++) {
            lastNames[i] = scanner.nextLine();
        
        }
        
        
     
        List<String> fullNames = new ArrayList<>();
      
        for (int i = 0; i < 5; i++) {
            fullNames.add(firstNames[i] + " " + lastNames[i]);
        }
    
       
        System.out.println("\nSorted names:");
        for (String fullName : fullNames) 
        {
            System.out.println(fullName);
        }
        
        scanner.close();
    }
}


