package Madhuri_Package;

import java.util.Arrays;

public class program2 {

	  public static void main(String args[]) { 
		  
		  String names [] = {"Darshan","Madhuri","Biren","Kartik"};
		  
		  System.out.println("Before sorting: " + Arrays.toString(names));
		  
		 Arrays.sort(names);
		 System.out.println("\nAfter sorting: " + Arrays.toString(names));
	  }
}








