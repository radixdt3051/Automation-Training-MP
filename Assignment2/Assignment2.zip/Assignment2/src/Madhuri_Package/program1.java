package Madhuri_Package;

public class program1 {
	
public static void  mp() {
	

		int a =5 , b=5;
		float c = 50.5f , d = 2;
	
		    int add  =   a + b;
			int substract =   a - b;
			int multiply =  a * b;
			float divide = c / d;
	
	    System.out.println("Addition:" +add);
		System.out.println("Substraction:" +substract);
		System.out.println("MUltiplication:" +multiply);
		System.out.println("Division:" +divide);
		
}
		
	public static void main(String[] args) {
			
	    program1 test = new program1();
	    test.mp();
	}
}

	
 
 


